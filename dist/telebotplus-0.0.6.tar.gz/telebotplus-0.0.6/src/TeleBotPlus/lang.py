import os
import MainShortcuts as ms
from . import HTML
from typing import *


class Lang:
  def __init__(self, path: str = "lang.json"):
    self.path = os.path.abspath(path)
    self.load()
    self.reload_categories()

  def reload_categories(self):
    def get_wrapper(cat: str):
      def wrapper(self, name: str, values: Union[Iterable, dict[str, Any]]) -> str:
        return self.get(cat, name, values)
      return wrapper
    for category in self.data:
      if not (category.startswith("_") or hasattr(self, category)):
        setattr(self, category, get_wrapper(category))

  def load(self, **kw):
    if os.path.exists(self.path):
      kw["path"] = self.path
      if not "like_json5" in kw:
        kw["like_json5"] = False
      self.data: dict[str, dict[str, Any]] = ms.json.read(**kw)
    else:
      self.data: dict[str, dict[str, Any]] = {}
    self.cache = {}

  def save(self, **kw):
    self.data["_format"] = "TeleBotPlus.lang"
    kw["data"] = self.data
    kw["path"] = self.path
    ms.json.write(**kw)

  def build_cache(self):
    for category in self.data:
      if not category.startswith("_"):
        for name in self.data[category]:
          self.cache[category, name] = HTML.from_dict(self.data[category][name])

  def get(self, category: str, name: str, values: Union[Iterable, dict[str, Any]]) -> str:
    if not (category, name) in self.cache:
      self.cache[category, name] = HTML.from_dict(self.data[category][name])
    return self.cache[category, name] % values
