def f0to1(index: dict) -> dict:
  new_index = {}
  new_index["format"] = 1
  new_index["objects"] = index
  return new_index
